﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace COMP123_S2017_FinalExam_StudentID
{
    public partial class Splashscreen1 : Form
    {
        public Splashscreen1()
        {
            InitializeComponent();
        }
        private void PickHighestCardForm_Load(object sender, EventArgs e)
        {
            //the timer is now going to start
            timeLeft = 10;
            timer1.Start();
        }

        public int timeLeft { get; set; }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (timeLeft > 0)
            {

                timeLeft = timeLeft - 1;

            }
            else

            {
                timer1.Stop();
                new PickHighestCardForm().Show();
                this.Hide();
            }
        }
        private void Splashscreen1_Scroll(object sender, ScrollEventArgs e)
        {

        }

        private void Splashscreen1_Load(object sender, EventArgs e)
        {

        }
        //Use timer class
        Timer tmr;
        private void Splashscreen1_Shown(object sender, EventArgs e)
        {
            tmr = new Timer();
            //set time interval 3 sec
            tmr.Interval = 3000;
            //starts the timer
            tmr.Start();
            tmr.Tick += tmr_Tick;
        }
        void tmr_Tick(object sender, EventArgs e)
        {
            //after 3 sec stop the timer
            tmr.Stop();
            //display mainform
            PickHighestCardForm mf = new PickHighestCardForm();
            mf.Show();
            //hide this form
            this.Hide();
        }

    }
}



   